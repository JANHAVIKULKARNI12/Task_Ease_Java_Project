
package tudu_2;


public class Tudu_2 {

    public static void main(String[] args) {
        Manager session = new Manager();
        session.run(); 
    }
    
}

//***************************************************************************************
//	END CODE
//***************************************************************************************
